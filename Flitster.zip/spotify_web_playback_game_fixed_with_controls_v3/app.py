
import os
import random
import requests
from flask import Flask, redirect, request, session, render_template, jsonify
from urllib.parse import urlencode

app = Flask(__name__)
app.secret_key = os.urandom(24)

CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
REDIRECT_URI = "http://127.0.0.1:8888/callback"

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"
API_BASE = "https://api.spotify.com/v1"

SCOPE = "streaming user-read-email user-read-private user-read-playback-state user-modify-playback-state"

@app.route("/")
def index():
    if "access_token" not in session:
        return redirect("/login")
    return render_template("index.html", access_token=session["access_token"])

@app.route("/login")
def login():
    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": REDIRECT_URI,
        "scope": SCOPE,
    }
    return redirect(f"{AUTH_URL}?{urlencode(params)}")

@app.route("/callback")
def callback():
    code = request.args.get("code")
    response = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
    )
    response_data = response.json()
    session["access_token"] = response_data.get("access_token")
    return redirect("/")

@app.route("/get-random-track")
def get_random_track():
    playlist_url = request.args.get("playlist_url")
    playlist_id = playlist_url.split("/")[-1].split("?")[0]
    headers = {"Authorization": f"Bearer {session['access_token']}"}
    r = requests.get(f"{API_BASE}/playlists/{playlist_id}/tracks", headers=headers)
    items = r.json().get("items", [])
    if not items:
        return jsonify({"error": "No tracks found"}), 404

    track = random.choice(items)["track"]
    return {
        "uri": track["uri"],
        "name": track["name"],
        "artist": track["artists"][0]["name"],
        "year": track["album"]["release_date"][:4],
    }

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8888, debug=True)
