
let deviceId = null;
let currentTrack = null;
let currentPlaylist = "";
let playerReady = false;

function enableControls() {
    document.getElementById("startBtn").disabled = false;
    document.getElementById("nextBtn").disabled = false;
}

window.onSpotifyWebPlaybackSDKReady = () => {
    const player = new Spotify.Player({
        name: 'Guess Game Player',
        getOAuthToken: cb => { cb(accessToken); },
        volume: 0.5
    });

    player.addListener('ready', ({ device_id }) => {
        console.log('Ready with Device ID', device_id);
        deviceId = device_id;
        playerReady = true;
        enableControls();
    });

    player.connect();
};

function startGame() {
    const playlist = document.getElementById("playlist").value;
    if (!playerReady || !playlist) return;
    currentPlaylist = playlist;
    loadAndPlayRandomTrack();
}

function nextTrack() {
    if (currentPlaylist && playerReady) {
        loadAndPlayRandomTrack();
    }
}

function loadAndPlayRandomTrack() {
    fetch("/get-random-track?playlist_url=" + encodeURIComponent(currentPlaylist))
        .then(res => res.json())
        .then(data => {
            currentTrack = data;
            document.getElementById("answer").style.display = "none";
            fetch('https://api.spotify.com/v1/me/player/play?device_id=' + deviceId, {
                method: 'PUT',
                body: JSON.stringify({ uris: [data.uri] }),
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + accessToken
                },
            });
        });
}

function pauseTrack() {
    fetch('https://api.spotify.com/v1/me/player/pause?device_id=' + deviceId, {
        method: 'PUT',
        headers: {
            'Authorization': 'Bearer ' + accessToken
        }
    });
}

function replayTrack() {
    if (currentTrack) {
        fetch('https://api.spotify.com/v1/me/player/play?device_id=' + deviceId, {
            method: 'PUT',
            body: JSON.stringify({ uris: [currentTrack.uri] }),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + accessToken
            },
        });
    }
}

function showAnswer() {
    if (currentTrack) {
        document.getElementById("answer").innerText = `${currentTrack.name} — ${currentTrack.artist} (${currentTrack.year})`;
        document.getElementById("answer").style.display = "block";
    }
}
